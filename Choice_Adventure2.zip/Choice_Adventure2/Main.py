from TC import *
from tkinter import *
from tkinter import messagebox
from random import *

root = Tk()
root.title("Choice Adventure 2")

Health = 100
Inventory = ["Pocket knife"]
Did_Die = False
No_Shelter = False
No_Button2 = False

def Menu1():
    clear_frame()
    Title = Label(root, text="Choice Adventure 2",padx = 200,pady = 200)
    Title.config(font= ("Courrier", 40))
    Title.place(x=25, y=25, anchor="center")
    Exit_but = Button(text = "Exit", command = exit,padx=50,pady=50, bg = "red")
    but1 = Button(text = "Start",padx=50,pady=50, command = Start,bg = "green")
    but2 = Button(text = "Credits",padx=50,pady=50,bg = "blue", command = Credits)

    Exit_but.grid(row=1,column=0)
    but1.grid(row=1,column=1)
    but2.grid(row=1,column=2)

    Title.grid(row=0, column=0,columnspan = 3)

def clear_frame():
    for widgets in root.winfo_children():
     widgets.destroy()

def Items():
    global Items_Inventory

    Items_Inventory= "\n"
    for i in Inventory:
        Items_Inventory += f"{i}\n"

def Func_Health_Death(Phrase):
    global Did_Die
    clear_frame()
    
    Phrase_End = Message(root, text= Phrase,padx = 10,pady = 100)
    Phrase_End.config(font= ("Courrier", 10))
    Phrase_End.grid(row=0,column=0,columnspan = 2)
    
    Phrase_Death = Message(root, text= Phrase_Health_Death,padx = 10,pady = 100)
    Phrase_Death.config(font= ("Courrier", 10))
    Phrase_Death.grid(row=2,column=0,columnspan = 2)

    Phrase_Death_Game_Over = Message(root, text= "GAME OVER",padx = 10,pady = 10, fg = "red")
    Phrase_Death_Game_Over.config(font= ("Courrier", 30))
    Phrase_Death_Game_Over.grid(row=1,column=0,columnspan = 2)

    Button_Restart = Button(text = "Restart",padx=50,pady=30, command = Start)
    Button_Exit = Button(text = "Exit", command = exit,padx=50,pady=50, bg = "red")

    Info_Label = Label(root, text= f"Health :{Health} \n\nInventory :{Items_Inventory}")
    Info_Label.grid(row=0,column=3)

    Button_Exit.grid(row=3,column=0)
    Button_Restart.grid(row=3,column=1)

    Did_Die = True

def Credits():
    clear_frame()
    Window = Message(root, text= Phrase_Credits,padx = 100,pady = 200)
    Window.config(font= ("Courrier", 10))
    Window.grid(row=0,column=0,columnspan = 2)
    Button_Back = Button(text = Text_Button_Back,padx=50,pady=30, command = Menu1, bg = "blue")
    Button_Back.grid(row = 1, column = 0)
    
def Base(Phrase,Func_Button1,Func_Button2,Text_Button1,Text_Button2):
    global Health
    global Inventory

    Items()
    clear_frame()

    Window = Message(root, text= Phrase,padx = 100,pady = 200)
    Window.config(font= ("Courrier", 10))
    Window.grid(row=0,column=0,columnspan = 2)

    Info_Label = Label(root, text= f"Health :{Health} \n\nInventory :{Items_Inventory}")
    Info_Label.grid(row=0,column=3)

    Button1 = Button(text = Text_Button1,padx=50,pady=30, command = Func_Button1, bg = "blue")
    Button2 = Button(text = Text_Button2,padx=50,pady=30, command = Func_Button2, bg = "blue")
    
    Button1.grid(row=1,column=0)
    if not No_Button2:
        Button2.grid(row=1,column=1)

    if Health <= 0:
        Func_Health_Death(Phrase)

def Func_Weather1(Phrase,Phrase_Sunny,Phrase_Raining,Phrase_Tornado,Phrase_Heatwave):
    Weather1 = randrange(1,5)
    if Weather1 == 1:
        Func_Sunny1()
    elif Weather1 == 2:
        Func_Rain1()
    elif Weather1 == 3:
        Func_Tornado1()
    elif Weather1 == 4:
        Func_Heatwave1()

    if Weather == "Sunny":
        Phrase = Phrase_Sunny
    elif Weather == "Raining":
        Phrase = Phrase_Raining
    elif Weather == "Tornado":
        Phrase = Phrase_Tornado
    elif Weather == "Heatwave":
        Phrase = Phrase_Heatwave
    
    return Phrase

def Func_Sunny1():
    global Weather 
    Weather = "Sunny"

def Func_Rain1():
    global Health
    global Weather
    Weather = "Raining"
    Health += -10

def Func_Tornado1():
    global Health
    global Weather
    Weather = "Tornado"
    Health += -50

def Func_Heatwave1():
    global Health
    global Weather
    Weather = "Heatwave"
    Health += -20

def Start():
    global Did_Die
    global No_Shelter
    global Starting_Label
    global Shelter1
    global Look_Food1
    global Fire1
    global Health
    global Inventory

    Health = 100
    Inventory = ["Pocket knife"]
    Did_Die = False
    No_Shelter = False
  
    Items()
    clear_frame()

    Starting_Label = Message(root, text= Phrase_Start,padx = 100,pady = 200)
    Starting_Label.config(font= ("Courrier", 10))
    Starting_Label.grid(row=0,column=0,columnspan = 3)

    Info_Label = Message(root, text= f"Health :{Health} \n\nInventory :{Items_Inventory}")
    Info_Label.grid(row=0,column=3)
   
    Look_Food1 = Button(text = "Look for food",padx=50,pady=30, command = Func_Look_Food1, bg = "blue")
    Fire1 = Button(text = "Make a fire",padx=50,pady=30, command = Func_Fire1, bg = "blue")
    Shelter1 = Button(text = "Shelter",padx=50,pady=30, command = Func_Shelter1, bg = "blue")

    Look_Food1.grid(row=1,column=0)
    Fire1.grid(row=1,column=1)
    Shelter1.grid(row=1,column=2)

def Death(Death_Message):
    clear_frame()
    
    Phrase_End = Message(root, text= Death_Message,padx = 10,pady = 100)
    Phrase_End.config(font= ("Courrier", 10))
    Phrase_End.grid(row=0,column=0,columnspan = 2)
    
    Phrase_Death_Game_Over = Message(root, text= "GAME OVER",padx = 10,pady = 10, fg = "red")
    Phrase_Death_Game_Over.config(font= ("Courrier", 30))
    Phrase_Death_Game_Over.grid(row=1,column=0,columnspan = 2)

    Button_Restart = Button(text = "Restart",padx=50,pady=50, command = Start)
    Button_Exit = Button(text = "Exit", command = exit,padx=50,pady=50, bg = "red")

    Button_Exit.grid(row=2,column=0)
    Button_Restart.grid(row=2,column=1)

def Func_Look_Food1():
    Base(Phrase_Look_Food1,Func_Beach1,Func_Forest1,Text_Beach1,Text_Forest1)

def Func_Fire1():
    Inventory.append("Fire")
    Base(Phrase_Fire1,Func_Pig1,Func_Ignore1,Text_Pig1,Text_Ignore1)

def Func_Shelter1():
    Base(Phrase_Shelter1,Func_Wood1,Func_Cave1,Text_Wood1, Text_Cave1)

def Func_Beach1():
    Base(Phrase_Beach1,Func_Island1,Func_Cave2,Text_Island1,Text_Cave1)

def Func_Forest1():
    Base(Phrase_Forest1,Func_Search1,Func_Berries1,Text_Search1, Text_Berries1)
    
    for i in Inventory:
        if i == "Fire" and not Did_Die:
            Pig2 = Button(text = Text_Pig1,padx=50,pady=30, command = Func_Pig1, bg = "blue")
            Pig2.grid(row=1,column=2)
            return
        elif i != "Fire" and not Did_Die:
            Pig2 = Button(text = Text_Pig1,padx=50,pady=30, command = Func_Pig1, state = DISABLED, bg = "blue")


    Pig2.grid(row=1,column=2)

def Func_Pig1():
    for i in Inventory:
        if i == "Fire":
            Inventory.remove("Fire")
    Base(Phrase_Pig1,Func_Shelter2,Func_Adventure1,Text_Shelter2, Text_Adventure1 )

def Func_Ignore1():
    Base(Phrase_Ignore1,Func_Climb1,Func_SOS1,Text_Climb1,Text_SOS1)

def Func_Wood1():
    Phrase_Wood1 = Func_Weather1(Phrase_Test,Phrase_Wood1_Sunny,Phrase_Wood1_Rain,Phrase_Wood1_Tornado,Phrase_Wood1_Heatwave )
    Base(Phrase_Wood1,Func_Bow1,Func_Tools1,Text_Bow1,Text_Tools1)

def Func_Cave1():
    Phrase_Cave1 = Func_Weather1(Phrase_Test,Phrase_Cave1_Sunny,Phrase_Cave1_Rain,Phrase_Cave1_Tornado,Phrase_Cave1_Heatwave)
    Base(Phrase_Cave1,Func_Tools1,Func_Farm1,Text_Tools1,Text_Farm1)

def Func_Island1():
    Base(Phrase_Island1,Func_Volcano1,Func_Plane1,Text_Volcano1,Text_Plane1)

def Func_Cave2():
    Phrase_Cave2 = Func_Weather1(Phrase_Test,Phrase_Cave2_Sunny,Phrase_Cave2_Rain,Phrase_Cave2_Tornado,Phrase_Cave2_Heatwave)
    Base(Phrase_Cave2,Func_Climb1,Func_Ignore2,Text_LB1,Text_Ignore1)

def Func_Search1():
    for i in Inventory:
        if i == "Fire":
            Inventory.remove("Fire")
    global Health
    Health += -30
    Phrase_Search1 = Func_Weather1(Phrase_Test,Phrase_Search1_Sunny, Phrase_Search1_Rain, Phrase_Search1_Tornado,Phrase_Search1_Heatwave)
    Base(Phrase_Search1,Func_Waterfall1,Func_Potato1,Text_Waterfall1,Text_Potato1)

def Func_Berries1():
    Base(Phrase_Berries1,Func_Run1,Func_Kill1,Text_Run1,Text_Kill1)
    

def Func_Shelter2():
    Phrase_Shelter2 = Func_Weather1(Phrase_Test,Phrase_Shelter2_Sunny,Phrase_Shelter2_Rain,Phrase_Shelter2_Tornado,Phrase_Shelter2_Heatwave )
    Base(Phrase_Shelter2,Func_Tools2,Func_River1,Text_Tools1,Text_River1)

def Func_Adventure1():
    Base(Phrase_Adventure1,Func_Temple1,Func_Ignore3,Text_Temple1,Text_Ignore1)

def Func_Climb1():
    for i in Inventory:
        if i == "Fire":
            Inventory.remove("Fire")

    Base(Phrase_Climb1,Func_Door1,Func_Ship1,Text_Door1,Text_Ship1)

def Func_SOS1():
    Base(Phrase_SOS1,Func_Swim1,Func_Sleep1,Text_Swim1,Text_Sleep1)

def Func_Bow1():
    Inventory.append("Bow and arrows")
    Base(Phrase_Bow1,Func_Fire2,Func_Hunt1,Text_Fire1,Text_Hunt1)

def Func_Tools1():
    Inventory.append("Axe")
    Base(Phrase_Tools1,Func_Dungeon1,Func_Rocky1,Text_Dungeon1,Text_Rocky1)

def Func_Farm1():
    Base(Phrase_Farm1,Func_Run2,Func_Fight1,Text_Run1,Text_Fight1)

def Func_Volcano1():
    Base(Phrase_Volcano1,Func_Climb2,Func_Around1,Text_Climb2,Text_Around1)

def Func_Plane1():
    global Health
    if Health < 100:
        Health = 100
    else:
        Inventory.append("First Aid Kit")

    Base(Phrase_Plane1,Func_Confront1,Func_Run3,Text_Confront1,Text_Run1)

def Func_Ignore2():
    Base(Phrase_Ignore2,Func_Play_Dead1,Func_Parkour1,Text_Play_Dead1,Text_Parkour1)

def Func_Waterfall1():
    Base(Phrase_Waterfall1,Func_Steal1,Func_Run4,Text_Steal1,Text_Run1)

def Func_Potato1():
    Base(Phrase_Potato1,Func_House1,Func_Hole1,Text_House1,Text_Hole1)

def Func_Run1():
    Base(Phrase_Run1,Func_Volcano1,Func_Village1,Text_Volcano1,Text_Village1)
    for i in Inventory:
        if i == "Fire":
            Inventory.remove("Fire")

def Func_Kill1():
    for i in Inventory:
        if i == "Bow and arrows":
            Death(Death_Bow_Kill1)
            return
        Death(Death_Kill1)

def Func_Tools2():
    Inventory.append("Axe")
    Base(Phrase_Tools2,Func_Bow2,Func_Hut1,Text_Bow1,Text_Hut1)
    
def Func_River1():
    Base(Phrase_River1,Func_Desert1,Func_Horse1,Text_Desert1,Text_Horse1)

def Func_Temple1():
    Base(Phrase_Temple1,Func_Door2,Func_Ladder1,Text_Door1,Text_Ladder1)

def Func_Ignore3():
    Base(Phrase_Ignore3,Func_Ship2,Func_Sky_Island1,Text_Pirate_Ship1,Text_Sky_Island1)

def Func_Door1():

    def Popup_Error():
        messagebox.showerror("Password Error", "The password is incorrect!")

    def Enter_Pass1():
        Correct = "correct"
        Ans = Entry1.get()
        if Ans.lower() == Correct:
            Func_Decrypt1()
        else:
            Popup_Error()

    def Update1(new_time):
        if new_time == 0:
            Func_Ship1()
        newer_time = 0
        newer_time += new_time-1
        Timer1.config(text= newer_time)
        Timer1.after(1000, lambda: Update1(newer_time))
    
    Items()
    clear_frame()
    Window = Message(root, text= Phrase_Door1,padx = 100,pady = 200)
    Window.config(font= ("Courrier", 10))
    Window.grid(row=0,column=0,columnspan = 2)
    Info_Label = Label(root, text= f"Health :{Health} \n\nInventory :{Items_Inventory}")
    Info_Label.grid(row=0,column=3)
    Entry1 = Entry(root,width=50)
    Button22 = Button(text = Text_Ship1,padx=50,pady=30, command = Func_Ship1)
    Entry1.grid(row=2,column=0)
    Button22.grid(row=1,column=1)
    Button3 = Button(text = "Enter",padx=50,pady=30, command = Enter_Pass1)
    Button3.grid(row=1,column=0)
    Timer1 = Message(root, text = "180",fg="red")
    Timer1.config(font= ("Courrier", 20))
    Timer1.grid(row=2,column=3)
    Timer1.after(1000, lambda: Update1(180))

def Func_Ship1():
    global Health
    Health += - 80
    Base(Phrase_Ship1,Func_Swim2,Func_Give1,Text_Swim1,Text_Give1)

def Func_Swim1():
    Base(Phrase_Swim1,Func_Hunt2,Func_Island2,Text_Hunt1,Text_Island1)

def Func_Sleep1():
    Base(Phrase_Sleep1,Func_Hunt2,Func_Island2,Text_Hunt1,Text_Island1)

def Func_Fire2():
    Inventory.append("Fire")
    Base(Phrase_Fire2,Func_Chicken1,Func_Cow1,Text_Chicken1,Text_Cow1)

def Func_Hunt1():
    Base(Phrase_Hunt1,Func_Chicken2,Func_Boar1,Text_Chicken1,Text_Boar1)

def Func_Dungeon1():
    Base(Phrase_Dungeon1,Func_Treasure1,Func_Weapon1,Text_Treasure1,Text_Weapon1)

def Func_Rocky1():
    Base(Phrase_Rocky1,Func_Walk1,Func_Ocean1,Text_Walk1,Text_Ocean1)

def Func_Run2():
    global Health
    Health += -50
    Base(Phrase_Run2,Func_Cave2,Func_Sound1,Text_Cave1,Text_Sound1)

def Func_Fight1():
    Death(Death_Fight1)

def Func_Play_Dead1():
    global Health
    Health += -50
    Base(Phrase_Play_Dead1,Func_Sneak1,Func_Walk2,Text_Sneak1,Text_Walk1)
    for i in Inventory:
        if i == "Bow and arrows" and not Did_Die:
            Revenge1 = Button(text = Text_Revenge1,padx=50,pady=30, command = Func_Revenge1, bg = "blue")
            Revenge1.grid(row=1,column=3) 
            return
        elif i != "Bow and arrows" and not Did_Die:
            Revenge1 = Button(text = Text_Revenge1,padx=50,pady=30, command = Func_Revenge1, state = DISABLED, bg = "blue")
            Revenge1.grid(row=1,column=3)
   
    
def Func_Parkour1():
    Death(Death_Parkour1)

def Func_Climb2():
    Death(Death_Climb2)

def Func_Around1():
    Base(Phrase_Around1,Func_Kill2,Func_Run5,Text_Magma_Kill1,Text_Run1)

def Func_Confront1():
    Inventory.append("Spear")
    Base(Phrase_Confront1,Func_Tracks1,Func_Opposite1,Text_Tracks1,Text_Opposite1)

def Func_Run3():
    Death(Death_Run3)

def Func_Steal1():
    Inventory.append("Potion")
    Base(Phrase_Steal1,Func_Drink1,Func_Keep1,Text_Drink1,Text_Keep1)

def Func_Run4():
    global Health
    Health += -20
    Base(Phrase_Run4,Func_Potato1,Func_Dungeon1,Text_Potato1,Text_Dungeon1)

def Func_House1():
    Death(Death_House1)

def Func_Hole1():
    global Health
    Health += -50
    Base(Phrase_Hole1,Func_Climb3,Func_Wait1,Text_Climbing1,Text_Wait1)
    for i in Inventory:
        if i == "Axe" and not Did_Die:
            Ladder1 = Button(text = Text_Ladders1,padx=50,pady=30, bg = "blue")
            Ladder1.grid(row=1,column=3)    
            return
        elif i != "Axe" and not Did_Die:
            Ladder1 = Button(text = Text_Ladders1,padx=50,pady=30, state = DISABLED, bg = "blue")
            Ladder1.grid(row=1,column=3)    


def Func_Village1():
    for i in Inventory:
        if i == "Bow and arrows":
            Base(Phrase_Village1,Func_Sneak2,Func_Attack1,Text_Sneak1,Text_Attack1)
            Leave1 = Button(text = Text_Leave1,padx=50,pady=30, command = Func_Leave1,bg = "blue")
            Leave1.grid(row=1,column=2)
            return
        Death(Death_Village1)

def Func_Bow2():
    Base(Phrase_Bow2,Func_River1,Func_Rocky1,Text_River1,Text_Rocky1)

def Func_Hut1():
    Base(Phrase_Hut1,Func_River1,Func_Rocky1,Text_River1,Text_Rocky1)

def Func_Desert1():
    Base(Phrase_Desert1,Func_Keep_Going1,Func_Back1,Text_Keep_Going1,Text_Back1)

def Func_Horse1():
    Phrase_Horse1 = "Do you travel around the island on your horse or do go back to your shelter? "
    Text_Back_Shelter1 = "Back to the shelter"

    if No_Shelter:
        Phrase_Horse1 = Phrase_Horse_No_Shelter1
        Text_Back_Shelter1 = Text_No_Shelter1
    Base(Phrase_Horse1,Func_Travel1,Func_Back_Shelter1,Text_Travel1,Text_Back_Shelter1)

def Func_Door2():
    Base(Phrase_Door2,Func_Loot1,Func_Leave2,Text_Loot1,Text_Leave1)

def Func_Ladder1():
    Base(Phrase_Ladder1,Func_Button1,Func_Hallway1,Text_Button1,Text_Hallway1)

def Func_Ship2():
    Inventory.append("Sword")
    Base(Phrase_Ship2,Func_Underwater1,Func_Lava1,Text_Underwater1,Text_Lava1)

def Func_Sky_Island1():
    Base(Phrase_Sky_Island1,Func_Eat1,Func_Sleep2,Text_Eat1,Text_Sleep1)

def Func_Decrypt1():
    Base(Phrase_Decrypt1,Func_Left1,Func_Right1,Text_Left1,Text_Right1)

def Func_Swim2():
    Death(Death_Swim2)

def Func_Give1():
    global Health
    Health += -10
    Base(Phrase_Give1,Func_Sky_Island1,Func_Lava1,Text_Sky_Island1,Text_Lava1)

def Func_Hunt2():
    Death(Death_Hunt2)

def Func_Island2():
    Death(Death_Island2)

def Func_Chicken1():
    global Chicken_Route
    Chicken_Route = True
    Base(Phrase_Chicken1,Func_Forest1,Func_Helicopter1,Text_Forest1,Text_Helicopter1)
    
def Func_Cow1():
    Base(Phrase_Cow1,Func_Noise1,Func_Trail1,Text_Noise1,Text_Trail1)

def Func_Chicken2():
    Base(Phrase_Chicken2,Func_Mountain1,Func_Ice1,Text_Mountain1,Text_Ice1)

def Func_Boar1():
    Base(Phrase_Boar1,Func_Mountain1,Func_Ice1,Text_Mountain1,Text_Ice1)

def Func_Treasure1():
    Inventory.append("Diamond")
    Base(Phrase_Treasure1,Func_Search2,Func_Leave3,Text_Search1,Text_Leave1)

def Func_Weapon1():
    Base(Phrase_Weapon1,Func_Search2,Func_Leave3,Text_Search1,Text_Leave1)

def Func_Walk1():
    Death(Death_Walk1)

def Func_Ocean1():
    Base(Phrase_Ocean1,Func_Swim3,Func_Sleep3,Text_Swim1,Text_Sleep1)

def Func_Sound1():
    Base(Phrase_Sound1,Func_Run6,Func_Fight2,Text_Run1,Text_Fight1)

def Func_Sneak1():
    global No_Button2
    No_Button2 = True
    Base(Phrase_Sneak1,Func_Nothing1,Func_Diamond1,Text_Nothing1,Text_Diamond1)
    for i in Inventory:
        if i == "Diamond" and not Did_Die:
            Button2 = Button(text = Text_Diamond1,padx=50,pady=30, command = Func_Diamond1, bg = "blue")
            Button2.grid(row=1,column=3) 
            No_Button2 = False
            return
        elif i != "Diamond" and not Did_Die:
            Button2 = Button(text = Text_Diamond1,padx=50,pady=30, command = Func_Diamond1, state = DISABLED, bg = "blue")
            Button2.grid(row=1,column=3)
            No_Button2 = False


def Func_Walk2():
    Death(Death_Walk2)

def Func_Revenge1():
    Death(Death_Revenge1)

def Func_Kill2():
    global Health
    Health += -20
    Base(Phrase_Kill2,Func_Rest1,Func_Plane1,Text_Rest1,Text_Plane1)

def Func_Run5():
    Death(Death_Run5)

def Func_Tracks1():
    Death(Death_Tracks1)

def Func_Opposite1():
    Death(Death_Opposite1)

def Func_Drink1():
    Death(Death_Drink1)

def Func_Keep1():
    Base(Phrase_Keep1,Func_Run7,Func_Fight3,Text_Run1,Text_Fight1)

def Func_Climb3():
    global No_Button2
    global Health 
    Health += -10
    No_Button2 = True
    Base(Phrase_Climb3,Func_Wait1,Func_Ladder1,Text_Wait1,Text_Ladders1)
    Button2 = Button(text = Text_Ladders1,padx=50,pady=30, command = Func_Ladder1, state = DISABLED, bg = "blue")
    if not Did_Die:
        Button2.grid(row=1,column=3)
    No_Button2 = False

def Func_Wait1():
    Death(Death_Wait1)

def Func_Sneak2():
    Base(Phrase_Sneak2,Func_Attack2,Func_Leave4,Text_Attack1,Text_Leave1)

def Func_Attack1():
    Death(Death_Wait1)

def Func_Leave1():
    Base(Phrase_Leave1,Func_Quicksand1,Func_Desert1,Text_Quicksand1,Text_Desert1)

def Func_Keep_Going1():
    Death(Death_Keep_Going1)

def Func_Back1():
    Death(Death_Back1)

def Func_Travel1():
    Base(Phrase_Travel1,Func_Mountain2,Func_Rest2,Text_Mountain1,Text_Rest1)

def Func_Back_Shelter1():
    Base(Phrase_Back_Shelter1,Func_Mountain2,Func_Rest2,Text_Mountain1,Text_Rest1)

def Func_Loot1():
    Inventory.append("Treasure")
    Base(Phrase_Loot1,Func_Loot2,Func_Leave2,Text_Loot1,Text_Leave1)

def Func_Leave2():
    Base(Phrase_Leave2,Func_Tree_House1,Func_Swamp1,Text_Tree_House1,Text_Swamp1)

def Func_Button1():
    Base(Phrase_Button1,Func_Climb4,Func_Break1,Text_Climb1,Text_Break1)

def Func_Hallway1():
    Death(Death_Hallway1)

def Func_Underwater1():
    Death(Death_Underwater1)
    
def Func_Lava1():
    for i in Inventory:
        if i == "Sword":
            Base(Phrase_Lava1,Func_Plane2,Func_Ignore4,Text_Plane1,Text_Ignore1)
            return
    Death(Death_Lava1)

def Func_Eat1():
    Death(Death_Eat1)

def Func_Sleep2():
    Base(Phrase_Sleep2,Func_Lightning1,Func_Opposite2,Text_Lightning1,Text_Opposite1)

def Func_Left1():
    Death(Death_Left1)

def Func_Right1():
    Death(Death_Right1)

def Func_Helicopter1():
    Inventory.append("Gasoline")
    for i in Inventory:
        if i == "Fire":
            Inventory.remove("Fire")    
    Base(Phrase_Helicopter1,Func_Ignore5,Func_Noise1,Text_Ignore1,Text_Noise1)

def Func_Noise1():
    for i in Inventory:
        if i == "Fire":
            Inventory.remove("Fire")     
    Base(Phrase_Noise1,Func_Fire3,Func_Rest3,Text_Fire1,Text_Rest1)

def Func_Trail1():
    Death(Death_Trails1)

def Func_Mountain1():
    Base(Phrase_Mountain1,Func_Climb5,Func_Bridge1,Text_Climb1,Text_Bridge1)

def Func_Ice1():
    Base(Phrase_Ice1,Func_Mountain3,Func_Icy1,Text_Mountain1,Text_Icy1)

def Func_Search2():
    Death(Death_Trails1)

def Func_Leave3():
    global No_Button2
    No_Button2 = True
    Base(Phrase_Leave3,Func_Temple2,Func_Build1,Text_Temple1,Text_Build1)   
    for i in Inventory:
        if i == "Axe" and not Did_Die:
            Button2 = Button(text = Text_Build1,padx=50,pady=30, command = Func_Build1, bg = "blue")
            Button2.grid(row=1,column=3)
            No_Button2 = False  
            return
        elif i != "Axe" and not Did_Die:
            Button2 = Button(text = Text_Build1,padx=50,pady=30, command = Func_Build1, state = DISABLED, bg = "blue")
            Button2.grid(row=1,column=3)
            No_Button2 = False 


def Func_Swim3():
    Death(Death_Swim3)

def Func_Sleep3():
    Death(Death_Sleep3)

def Func_Run6():
    Death(Death_Run6)

def Func_Fight2():
    Death(Death_Fight2)

def Func_Nothing1():
    Death(Death_Nothing1)

def Func_Diamond1():
    global Health
    Health += 20
    Inventory.remove("Diamond")
    Base(Phrase_Diamond1,Func_Stay_Away1,Func_Fight4,Text_Stay_Away1,Text_Fight1)

def Func_Rest1():
    Death(Death_Rest1)

def Func_Run7():
    Death(Death_Run7)

def Func_Fight3():
    global Health
    Health += -10
    for i in Inventory:
        if i == "Potion":
            Inventory.remove("Potion")    
    Base(Phrase_Fight3,Func_Rest4,Func_Fire4,Text_Rest1,Text_Fire1)

def Func_Attack2():
    Inventory.append("Sword")
    Inventory.append("Diamond")
    Base(Phrase_Attack2,Func_Cave2,Func_Temple1,Text_Cave1,Text_Temple1)

def Func_Leave4():
    Death(Death_Leave4)

def Func_Quicksand1():
    Death(Death_Quicksand1)

def Func_Mountain2():
    Death(Death_Mountain2)

def Func_Rest2():
    Phrase_Rest2 = Func_Weather1(Phrase_Test,Phrase_Rest2_Sunny,Phrase_Rest2_Rain,Phrase_Rest2_Tornado,Phrase_Rest2_Heatwave)
    Base(Phrase_Rest2,Func_Smoke1,Func_Animals1,Text_Smoke1,Text_Animals1)

def Func_Loot2():
    Death(Death_Loot2)

def Func_Tree_House1():
    Base(Phrase_Tree_House1,Func_Desert1,Func_Horse1,Text_Desert1,Text_Horse1)

def Func_Swamp1():
    Base(Phrase_Swamp1,Func_Witch1,Func_Travel1,Text_Witch1,Text_Travel1)

def Func_Climb4():
    Base(Phrase_Climb4,Func_Jump1,Func_Stay1,Text_Jump1,Text_Stay1)

def Func_Break1():
    Base(Phrase_Break1,Func_Rock1,Func_Hear1,Text_Rock1,Text_Hear1)

def Func_Plane2():
    Base(Phrase_Plane2,Func_Control1,Func_Parachute1,Text_Control1,Text_Parachute1)

def Func_Ignore4():
    Base(Phrase_Ignore4,Func_Mine1,Func_Flower1,Text_Mine1,Text_Flower1)

def Func_Lightning1():
    Death(Death_Lightning1)

def Func_Opposite2():
    Base(Phrase_Opposite2,Func_Sea1,Func_Dragon1,Text_Sea1,Text_Dragon1)

def Func_Ignore5():
    Base(Phrase_Ignore5,Func_Item1,Func_Snake1,Text_Item1,Text_Snake1)

def Func_Noise2():
    Base(Phrase_Noise2,Func_Fire3,Func_Rest3,Text_Fire1,Text_Rest1)

def Func_Fire3():
    Inventory.append("Fire")
    Base(Phrase_Fire3,Func_Throw1,Func_Run8,Text_Throw1,Text_Run1)

def Func_Rest3():
    Base(Phrase_Rest3,Func_Fight5,Func_Run8,Text_Fight1,Text_Run1)

def Func_Climb5():
    Death(Death_Climb5)

def Func_Bridge1():
    Death(Death_Bridge1)

def Func_Mountain3():
    Death(Death_Mountain3)

def Func_Icy1():
    Death(Death_Icy1)

def Func_Temple2():
    Base(Phrase_Temple2,Func_Flare1,Func_Armor1,Text_Flare1,Text_Armor1)

def Func_Build1():
    Base(Phrase_Build1,Func_Fire6,Func_Cave3,Text_Fire1,Text_Cave1)

def Func_Stay_Away1():
    Death(Death_Stay_Away1)

def Func_Fight4():
    global Health
    Health += -30
    Inventory.append("Key")
    Base(Phrase_Fight4,Func_Stay2,Func_Climb6,Text_Stay1,Text_Climb1)
    if not Did_Die:
        Tribe1 = Button(text = Text_Tribe1,padx=50,pady=30, command = Func_Tribe1, bg = "blue")
        Tribe1.grid(row=1,column=2)

def Func_Rest4():
    Death(Death_Rest4)

def Func_Fire4():
    Death(Death_Fire4)

def Func_Smoke1():
    Death(Death_Smoke1)

def Func_Animals1():
    Death(Death_Animals1)

def Func_Witch1():
    Death(Death_Witch1)

def Func_Jump1():
    Death(Death_Jump1)

def Func_Stay1():
    Base(Phrase_Stay1,Func_Rock1,Func_Hear1,Text_Stay1,Text_Hear1)

def Func_Rock1():
    Death(Death_Rock1)

def Func_Hear1():
    Death(Death_Hear1)

def Func_Control1():
    Death(Death_Control1)

def Func_Parachute1():
    global Health
    Health += -50
    Base(Phrase_Parachute1,Func_Mine1,Func_Flower1,Text_Mine1,Text_Flower1)

def Func_Mine1():
    Death(Death_Mine1)

def Func_Flower1():
    Death(Death_Flower1)

def Func_Sea1():
    Death(Death_Sea1)
    
def Func_Dragon1():
    Death(Death_Dragon1)

def Func_Item1():
    Inventory.append("Map")
    Base(Phrase_Item1,Func_First1,Func_Second1,Text_First1,Text_Second1)

def Func_Snake1():
    Death(Death_Snake1)

def Func_Throw1():
    Base(Phrase_Throw1,Func_Hide1,Func_Swim4,Text_Hide1,Text_Swim1)

def Func_Run8():
    Death(Death_Run8)

def Func_Fight5():
    Death(Death_Fight5)

def Func_Flare1():
    Have_Axe = False
    Phrase_Flare1 = Phrase_Flare1_Axe
    Inventory.append("Flare gun")
    for i in Inventory:
        if i == "Axe":
            Have_Axe = True
    if Have_Axe == False:   
        Inventory.append("Axe")
        Phrase_Flare1 = Phrase_Flare1_No_Axe
    Base(Phrase_Flare1,Func_Boat1,Func_Hut2,Text_Boat1,Text_Hut1)

def Func_Armor1():
    Base(Phrase_Armor1,Func_Run9,Func_Mountain4,Text_Run1,Text_Mountain1)

def Func_Fire6():
    Death(Death_Fire6)

def Func_Cave3():
    Death(Death_Cave3)

def Func_Stay2():
    Death(Death_Stay2)

def Func_Climb6():
    Base(Phrase_Climb6,Func_Decrypt2,Func_Shoot1,Text_Decrypt1,Text_Shoot1)

def Func_Tribe1():
    Death(Death_Tribe1)

def Func_First1():
    Base(Phrase_First1,Func_Ladder2,Func_Tent1,Text_Ladder1,Text_Tent1)

def Func_Second1():
    Base(Phrase_Second1,Func_Ladder2,Func_Tent1,Text_Ladder1,Text_Tent1)

def Func_Hide1():
    Death(Death_Hide1)

def Func_Swim4():
    Death(Death_Swim4)

def Func_Boat1():
    Death(Death_Boat1)

def Func_Hut2():
    Death(Death_Hut2)

def Func_Run9():
    Death(Death_Run9)

def Func_Mountain4():
    Death(Death_Mountain4)

def Func_Decrypt2():

    def Popup_Error1():
        messagebox.showerror("Password Error", "The password is incorrect!")

    def Enter_Pass1():
        Correct = "marc"
        Ans = Entry1.get()
        if Ans.lower() == Correct:
            Func_Correct1()
        else:
            Popup_Error1()

    def Update1(new_time):
        if new_time == 0:
            Func_Shoot1()
        newer_time = 0
        newer_time += new_time-1
        Timer1.config(text= newer_time)
        Timer1.after(1000, lambda: Update1(newer_time))
    
    Items()
    clear_frame()
    Window = Message(root, text= Phrase_Decrypt2,padx = 100,pady = 200)
    Window.config(font= ("Courrier", 10))
    Window.grid(row=0,column=0,columnspan = 2)
    Info_Label = Label(root, text= f"Health :{Health} \n\nInventory :{Items_Inventory}")
    Info_Label.grid(row=0,column=3)
    Entry1 = Entry(root,width=50)
    Button22 = Button(text = Text_Shoot1,padx=50,pady=30, command = Func_Shoot1)
    Entry1.grid(row=2,column=0)
    Button22.grid(row=1,column=1)
    Button3 = Button(text = "Enter",padx=50,pady=30, command = Enter_Pass1)
    Button3.grid(row=1,column=0)
    Timer1 = Message(root, text = "180",fg="red")
    Timer1.config(font= ("Courrier", 20))
    Timer1.grid(row=2,column=3)
    Timer1.after(1000, lambda: Update1(180))

def Func_Shoot1():
    Death(Death_Shoot1)
    
def Func_Ladder2():
    Death(Death_Ladder2)

def Func_Tent1():
    Base(Phrase_Tent1,Func_Ladder2,Func_Pull1,Text_Ladder1,Text_Pull1)

def Func_Correct1():
    Base(Phrase_Correct1,Func_WIN,Func_Guns1,Text_WIN,Text_Guns1)

def Func_Pull1():
    Death(Death_Pull1)

def Func_Guns1():
    Death(Death_Guns1)

def Func_WIN():
    global Health
    global Inventory

    Items()
    clear_frame()

    Window = Message(root, text= Phrase_WIN,padx = 100,pady = 200)
    Window.config(font= ("Courrier", 20))
    Window.grid(row=0,column=0,columnspan = 2)

    Info_Label = Label(root, text= f"Health :{Health} \n\nInventory :{Items_Inventory}")
    Info_Label.grid(row=0,column=3)
    
    Win = Message(root, text= "YOU WIN",padx = 10,pady = 10, fg = "yellow")
    Win.config(font= ("Courrier", 30))
    Win.grid(row=1,column=0,columnspan = 2)

    Button_Restart = Button(text = "Restart",padx=50,pady=50, command = Start)
    Button_Exit = Button(text = "Exit", command = exit,padx=50,pady=50, bg = "red")

    Button_Exit.grid(row=2,column=0)
    Button_Restart.grid(row=2,column=1)

Menu1()

mainloop()