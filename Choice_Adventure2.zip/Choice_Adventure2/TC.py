Phrase_Credits = " Game Idea: Marc Aoun \n Programmer: Marc Aoun \n Story Board: Marc Aoun \n Game Developper: Marc Aoun \n Director: Marc Aoun \n Manager: Marc Aoun \n Tester: Marc Aoun    "
Text_Button_Back = "Back"

Phrase_Test = "Test"

Phrase_Start = "Your plane crashes in a mysterious island and the only thing on you is a pocket knife. Survive and get rescued before your HP goes down to 0. "
Phrase_Health_Death = "Your health has fallen to 0 or lower! **note that weather damage is random and that you can take the same path again without dying**"
Phrase_Health_Death_Game_Over = "GAME OVER"

Phrase_Look_Food1 = "As you start to look around, you find a beach behind you and a forest infront of you. Which direction do you go?"
Text_Beach1 = "Beach"
Text_Forest1 = "Forest"

Phrase_Fire1 = "You successfully created a fire. While you are putting more branches in your fire, you spot a pig walking past you. Do you cook it or leave it alone?"
Text_Pig1 = "Pig"
Text_Ignore1 = "Ignore"

Phrase_Shelter1 = "Do you stack logs vertically against a tree to form a hut or do you go find a cave?"
Text_Wood1 = "Build hut"
Text_Cave1 = "Cave"

Phrase_Beach1 = "You find some coconuts on top of a palm tree. As you look around for some more coconuts, you find a cave which you can shelter at. Beyond that, you also find an island far away. Do you shelter in the cave or swim towards that island?"
Text_Island1 = "Island"

Phrase_Forest1 = "After a while of searching in the forest for food, you end up finding a pig eating berries. Do you keep on searching for food in the forest, eat the berries or eat the pig? **You can only cook the pig if you made a fire**"
Text_Search1 =  "Continue searching"
Text_Berries1 =  "Berries"

Phrase_Pig1 = "After that delicious meal, would you want to find shelter or start adventuring?"
Text_Shelter2 = "Find shelter"
Text_Adventure1 = "Adventure"

Phrase_Ignore1 = "Far away you spot a mountain, do you climb it or spell SOS using wood and hope you get rescued?"
Text_Climb1 = "Climb"
Text_SOS1 = "Build a SOS out of wood"

Phrase_Wood1_Sunny = "You wake up to a sunny day, Do you make a bow and arrow or do you make an axe made out of stone"
Phrase_Wood1_Rain = "You wake up to heavy rain which turned the dirt under you into mud which causes you to slip and hurt you arm (-10HP). Do you make a bow and arrow or do you make an axe made out of stone"
Phrase_Wood1_Tornado = "In the middle of the night, a tornado appears far away. Its too far to kill you but its close enough to send heavy winds towards you which causes -50HP in damages when one of the logs falls on you. Do you make a bow and arrow or do you make an axe made out of stone"
Phrase_Wood1_Heatwave = "You wake up to a very hot day, enough to give you sunburns everywhere which causes -20HP. Do you make a bow and arrow or do you make an axe made out of stone"
Text_Bow1 = "Bow and arrows"
Text_Tools1 = "Axe made out of stone"

Phrase_Cave1_Sunny = "You wake up to a sunny day. After a while inside of your cave, you decide that you want to do something productive for your survival. Do you create an axe made out of stone or grow a farm from seeds and vegetables?"
Phrase_Cave1_Rain = "You wake up to rainy morning which caused mud in front of your cave. You stept on in and slipped (-10HP). After a while inside of your cave, you decide that you want to do something prodoctive for your survival. Do you create an axe made out of stone or grow a farm from seeds and vegetables?"
Phrase_Cave1_Heatwave = "You wake up to an unberable heat which gave you a heatstroke (-30HP). After a while inside of your cave, you decide that you want to do something prodoctive for your survival. Do you create an axe made out of stone or grow a farm from seeds and vegetables?"
Phrase_Cave1_Tornado = "In the middle of the night, you hear a sound outside your cave and as you get out so see what going on. A tornado comes out of nowhere and blows you away so you run back to you cave and hide (-50HP). After a while inside of your cave, you decide that you want to do something prodoctive for your survival. Do you create an axe made out of stone or grow a farm from seeds and vegetables?" 

Text_Tools1 = "Axe made out of stone"
Text_Farm1 = "Farm"

Phrase_Island1 = "You look around and see the plane that you parachuted from. It seems to be broken but maybe there might be some sort of items in it. You also find a volcano far ahead. Do you search the plane or go towards the volcano? "
Text_Volcano1 = "Volcano"
Text_Plane1 = "Plane"

Phrase_Cave2_Sunny = "You wake up to a sunny day. While you are looking for fruits to eat so you can store it in your cave, a huge lightbeam comes shooting out of the tip of a mountain. Do you check it out or ignore it?"
Phrase_Cave2_Rain= "You wake up to a very rainy day. When you try to get up, you accidently slip and fall onto some rocks in your cave... ouch. While you are looking for fruits to eat so you can store it in your cave, a huge lightbeam comes shooting out of the tip of a mountain. Do you check it out or ignore it?"
Phrase_Cave2_Tornado = "You wake up to a very windy night. You get out of your cave to see what is happening and you witness a tornado ahead. A small tree falls on you and injures you but luckily the cave was there to block it from completly falling on you. Though you take -50HP. The next day, while you are looking for fruits to eat so you can store it in your cave, a huge lightbeam comes shooting out of the tip of a mountain. Do you check it out or ignore it?"
Phrase_Cave2_Heatwave = "You wake up to an extremely hot day. While you are looking for fruits to eat so you can store it in your cave you get sunburned everywhere and take -20 HP because of it. As you are in pain, a huge lightbeam comes shooting out of the tip of a mountain. Do you check it out or ignore it?"
Text_LB1 = "Light beam"

Phrase_Search1_Sunny = "After a while of searching for food on a very hot day, you take -30HP from lack of food, tiredness and heat. Far away you find potatoes that you could eat but in the opposite way you find a waterfall that seems to have a cave behind it. Do you go eat the potatoes or check out the waterfall?"
Phrase_Search1_Rain = "A few days later of searching, it starts to rain very heavely to the point where you can barely see. You walk around to find a shelter to hide in for a bit and accidently hit your head on a tree which causes -10HP. After a while of searching for food, you take another -30HP from lack of food, tiredness and heat. Far away you find potatoes that you could eat but in the opposite way you find a waterfall that seems to have a cave behind it. Do you go eat the potatoes or check out the waterfall?"
Phrase_Search1_Tornado = "A few days later of searching, A very heavy wind blows on you and pushes you of a small cliff which causes -50HP. After a while of searching for food on a very hot day, you take another -30HP from lack of food, tiredness and heat. Far away you find potatoes that you could eat but in the opposite way you find a waterfall that seems to have a cave behind it. Do you go eat the potatoes or check out the waterfall?"
Phrase_Search1_Heatwave = "After a while of searching for food on an extremely hot day, you take -30HP from lack of food and tiredness and another -20HP from the heat. Far away you find potatoes that you could eat but in the opposite way you find a waterfall that seems to have a cave behind it. Do you go eat the potatoes or check out the waterfall?"
Text_Waterfall1 = "Waterfall"
Text_Potato1 = "Potatoes"

Phrase_Berries1 = "While eating some berries, you find a goblin carving something with his dagger. Do you run away or kill him?"
Text_Run1 = "Run away"
Text_Kill1 = "Try to sneak up and kill him"

Phrase_Shelter2_Sunny = "You find a place full of small fallen or tilted trees and bushes where you can sleep under. You wake up the next day to a sunny morning. Do you make an axe made out of stone or walk towards a river where you can wash and cool yourself down?"
Phrase_Shelter2_Rain = "You find a place full of small fallen or tilted trees and bushes where you can sleep under. You wake up in the middle of the night because of the rain. Lack of sleep causes -10HP. Do you make an axe made out of stone or walk towards a river where you can wash and cool yourself down?"
Phrase_Shelter2_Tornado = "You find a place full of small fallen or tilted trees and bushes where you can sleep under. All of a sudden, the island is filled with heavy wind which causes some of the trees that are tilted over you to fall and hurt you, dealing -50HP. Do you make an axe made out of stone or walk towards a river where you can wash yourself from the blood and injuries caused by the fallen trees?"
Phrase_Shelter2_Heatwave = "You find a place full of fallen or tilted trees and bushes where you can sleep under. You wake up the next morning to an extremely hot day that caused multiple sunburns which causes -20HP. Do you make an axe made out of stone or walk towards a river where you can wash and cool yourself?"
Text_River1 = "River"

Phrase_Adventure1 = "While you look around the island, you find an ancient temple. Do you enter the temple or ignore it?"
Text_Temple1 = "Temple"

Phrase_Climb1 = "At the top of the mountain, you look around and find a weird metal door that leads inside of a cave. When trying to approach it you find a cruise ship far away. Do you try to chase after the ship and hope you can get rescued or ignore it and try to open the metal door? "
Text_Door1 = "Door"
Text_Ship1 = "Cruise Ship"

Phrase_SOS1 = "After building an SOS out of branches, you decide that you need a break. Do you swim around or go to sleep?"
Text_Swim1 = "Swim around"
Text_Sleep1 = "Sleep"

Phrase_Bow1 = 'Do you go hunting or do you start a fire?'
Text_Hunt1 = 'Hunting'
Text_Fire1 = "Fire"

Phrase_Tools1 = "After a few days of looking around in this island, you end up finding two things. First you find a dungeon leading underground and second you find a rocky biome. Which place do you go first?"
Text_Dungeon1 = "Dungeon"
Text_Rocky1 = "Rocky biome"

Phrase_Farm1 = "After a few weeks of growing vegtables from your farm, a pack of hungry wolves surround you and your farm. Do you fight against them or run away?"
Text_Fight1 = "Fight"

Phrase_Volcano1 = "The volcano is bigger than you thought. Do you climb the volcano to the top or go around it"
Text_Climb2 = "Volcano"
Text_Around1 = "Go around it"

Phrase_Plane1 = "As you look around the plane crash, you find nothing except for some metal. You enter the plane and find a First Aid Kit. As you leave the plane wreckage, you find a person from an ancient tribe looking around for something. Do you confront him or do you run away? "
Text_Confront1 = "Confront"

Phrase_Ignore2 = "As you ignore the light beam, you look around in the mysterious island for a couple days. All of a sudden you see a group of people in an ancient tribe running towards you. They throw a stone spear at you and cuts your chest. Do you play dead or do you parkour and run away from them?"
Text_Play_Dead1 = "Play dead"
Text_Parkour1 = "Parkour and run away"

Phrase_Waterfall1 = "As you enter the secret cave behind the waterfall, you find a cult standing in a circle. They wear long robes and are looking down while chanting something. On the floor, 10 feet from you, there seems to be a potion in a bottle. Do you steal the potion or do you just run away and never come back?"
Text_Steal1 = "Potion"

Phrase_Potato1 = "You finaly ate something after all that time, the potato was raw but still edible. You walk around the island for a couple of days until you find what seems to be an abanded house in the middle of the forest. Do you enter the house or keep on walking?"
Text_House1 = "Enter"
Text_Hole1 = "Ignore"

Phrase_Run1 = "As you run away, you find and village, and beyond that you find a volcano. Do you go towards the volcano or towards the village?"
Text_Village1 = "Head towards the village"

Death_Kill1 = "You sneak up behind the goblin and just about you go to stab him with the pocket knife, he hears and jumps on you with his dagger in his hand. He slices and kills you before you can defend yourself."
Death_Bow_Kill1 = "You sneak up behind the goblin and shoot an arrow at him. You stab him in the back but he survives and jumps on you with his dagger in his hand. He slices and kills you before you can even reload the other arrow."

Phrase_Tools2 = "Do you make a bow and arrows or do you make a wooden hut with the axe you created"
Text_Hut1 = "Wooden hut"

Phrase_River1 = "After a while of swiming in the river, you decide to follow it and to just go with the current. You encounter a group of horses and after another few minutes of swimming you find a desert. Do you tame one of the horses or go walk in the desert? "
Text_Desert1 = "Desert"
Text_Horse1 = "Horse"

Phrase_Temple1 = "You enter this weird and ancient temple. As you look around you find a trap door leading to a basement and a ladder that leads to the another floor. Which one do you choose?"
Text_Down1 = "Down"
Text_Ladder1 = "Up"

Phrase_Ignore3 = "As you adventure around the mysterious island, you come across two things. A broken pirate ship at the shore and a sky island above the clouds. The sky island has a rope that is hanging down from it which you pulled on to make sure its not loose. Do you go in the pirate ship or do you climb up all the way to the sky island?"
Text_Pirate_Ship1 = "Broken pirate ship"
Text_Sky_Island1 = "Sky island"

Phrase_Door1 = "As you come close to the door, you hear a beep and all of a sudden a timer of 3 minutes pops up. You notice a place to digitally write a password and above that you find the numbers: '3','15','18','18','5','3','20'. Figure out the password in 3 minutes or else you have no choice other than to chase after the cruise ship."

Phrase_Ship1 = "As you chase the cruise ship, you trip over a bunch of rocks and fall on the side of the mountain which causes -80HP in injuries. Now at the shore, do you swim towards the cruise ship or do you give up? "
Text_Give1 = "Give up"

Phrase_Swim1 = "After swimming in the ocean for fun, you find a different island up ahead. Do you swim to that island or stay in the same one and hunt for food?"

Phrase_Sleep1 = "After a good night sleep, you look around and find a different island up ahead. Do you swim to that island or stay in the same one and hunt for food?"

Phrase_Fire2 = "After creating a fire, you look around and find a chicken and a cow. Which one do you eat?"
Text_Chicken1 = "Chicken"
Text_Cow1 = "Cow"

Phrase_Hunt1 = "You come across a chicken and a boar. Which one do you eat?"
Text_Boar1 = "Boar"

Phrase_Dungeon1 = "As you look around in the dungeon, you find two doors, one of them has a sign that says 'Treasure' and the other has a sign that says 'Weapons'. Do you go through the door that says Treasure or the door that says Weapons?"
Text_Treasure1 = "Treasure"
Text_Weapon1 = "Weapon"

Phrase_Rocky1 = "After a few days of walking in a weird rocky biome. You spot the ocean far away. Do you head towards the ocean or do you keep on walking?"
Text_Walk1 = "Keep on walking"
Text_Ocean1 = "Ocean"

Phrase_Run2 = "As you run away, a wolf jumps on you and bites your back. This causes -50HP, but luckily you escape from them. While talking a rest, you hear a loud sound. Do you go towards that sound or do you go back to your cave?"
Text_Sound1 = "Sound"

Death_Fight1 = "There are too many wolves for you to defend against, they all jump on you and eat you alive."

Phrase_Play_Dead1 = "You lay down on the ground surrounded by blood. The tribe look at you and assume that you are really dead. Luckly the spear did not hit a vital organ and you survive but lose -50HP. Since your mad at the tribe, do you take revenge and kill them with a bow and arrow, walk away or sneak into their village? **You need a bow and arrow or/and a sword to take revenge**"
Text_Revenge1 = "Revenge"
Text_Sneak1 = "Sneak"

Death_Parkour1 = "You run around the forest to get away but you have no chance since your injured and they know the forest by heart. They catch up and kill you. You did not think this through..."

Death_Climb2 = "You climb to the top of the volcano and look down bellow to find lava inside of it. You feel a small earthquake happening and all of a sudden, an eruption occurs. Theres nothing left of you anymore."

Phrase_Around1 = "As you go around the volcano, You find a weird cave that leads inside of the volcano. You look closer and find a bunch of weird magma creatures that are about 1 foot tall. They start to run towards you. Do you fight them or do you run away?"
Text_Magma_Kill1 = "Kill them"

Phrase_Confront1 = "As you confront the tribe person, you go to try to talk to him and see if he knows english but as soon as he hears you coming close he pulls out a spear. You panic and throw your pocket knife at him and very luckily stab him in the head before he can throw his spear at you. You claim his spear. You look down at the ground and find his tracks. Do you follow his tracks or go the opposite direction?"
Text_Tracks1 = "Tracks"
Text_Opposite1 = "Opposite direction"

Death_Run3 = "As you trun around to start running, he hears you and throws his spear at your neck, instantly killing you."

Phrase_Steal1 = "Now that you aquired the mysterious potion, do you drink it or do you keep it with you?"
Text_Drink1 = "Drink"
Text_Keep1 = "Keep"

Phrase_Run4 = "You turn around to run away and a few steps later, you find one of the cult members standing around. He hears you and starts talking in a weird gibberish language. He pulls out a potion in his pocket and throws it at your arm and then you start to feel a burning sensation which causes -20HP. So for payback you punch him in the face and knock him out. Beside him you find an underground dungeon. Do you go back to the place full of potatoes or do you go down this dungeon? "

Death_House1 = "You walk in the house and before you can even walk around a goblin jumps on you and slits your throat, killing you almost immediately."

Phrase_Hole1 = "As you walk around the forest, you see this big and amazing looking tree far away. While you were distracted by the tree, you fall into a deep hole in the ground and take -50HP from fall damage. There is only a log in the pit. Do you try to climb up, save your energie and wait for something to happen or do you create a ladder using your axe by chopping at the log? **You can only create a ladder if you have an axe** "
Text_Wait1 = "Wait"

Phrase_Village1 = "You look around in this weird village and find a few houses. You enter one of the houses and find nothing of importance. You look around some more and then you hear someone opening the door, its a goblin. Quickly you take out your bow and shoot him before he notices you. You look outside and see more of these goblins. In another house, you find a goblin holding a map. Do you sneak your way around the village, attack the goblin with the map or do you leave the village?"
Text_Attack1 = "Attack"
Text_Leave1 = "Leave"
Death_Village1 = "You look around in this weird village and find a few houses. You enter one of the houses and find nothing of importance. You look around some more and then you hear someone opening the door, its a goblin. You take out your pockets knife but he hears you and jumps on you. You stab him in the stomach but the scratches your face with his long and sharp fingernails until you die."

Phrase_Bow2 = "Now that you have a bow and arrows, do you swim around in a river to cool yourself down or do you head towards a rocky biome that you found far away?"

Phrase_Hut1 = "Now that you made a nice wooden hut, do you swim around in a river to cool yourself down or do you head towards a rocky biome that you found far away?"

Phrase_Desert1 = "After days of walking in the hot desert. You find yourself dehydrated and sunburned. Do you go back to the forest or do you keep on going?"
Text_Keep_Going1 = "Keep on going"
Text_Back1 = "Go back"

Phrase_Horse1 = "Do you travel around the island on your horse or do go back to your shelter? "
Phrase_Horse_No_Shelter1 = "You find a nice cave that you can shelter at. Do you travel around the island on your horse or do you shelter at the cave? "
Text_Travel1 = "Travel"
Text_Back_Shelter1 = "Back to the shelter"
Text_No_Shelter1 = "Cave"

Phrase_Door2 = "You find a stairway leading down bellow. You come across a room full of treasure at the end of a hallway. Do you loot the treasure or do you go back up the stairway and leave the temple?"
Text_Loot1 = "Loot"

Phrase_Ladder1 = "You find yourself in a big room surrounded by spiderweb and random ancien items. You also find a hallway and behind you you find a button. Do you go through the hallway or do you press the button? "
Text_Button1 = "Button"
Text_Hallway1 = "Hallway"

Phrase_Ship2 = "You look around the broken pirate ship for anything else and the to your suprise, you find an ancient underwater city about 50m under water and beyond that you see a lava island. Do you swim to the underwater city or swim to the lava island?"
Text_Underwater1 = "Underwater city"
Text_Lava1 = "Lava island"

Phrase_Sky_Island1 = "You finally climb to see a huge bizarre forest on top of the clouds. You walk on the cloud since they are soft and dense on this sky island. Then you decide to step into the forest ontop of the clouds that you walked on. You get pretty hungry and tired, do you eat this weird fruit growing from a tree or do you sleep?"
Text_Eat1 = "Eat"

Phrase_Decrypt1 = "Good job you deciphered the code! You enter the door to find an empty millatry base. You walk for about 10 minutes before you find two doors, one on your left and another on your right. The one one the left has a 'DO NOT ENTER' sign ontop of it and the other has a skull symbol ontop of it. Which door do you pick?"
Text_Left1 = "Left"
Text_Right1 = "Right"

Death_Swim2 = "You swim towards the ship until you see a shadowy figure underwater. Before you can even realise its a shark, it bites your limbs off."

Phrase_Give1 = "You are completly out of breath,tired and nauseous (-10HP). You adventure for a few days and find and an island full of magma and a sky island above the clouds. The sky island has a rope that is hanging down from it which you pulled on to make sure its not loose. Do you swim to the magma island or do you climb up all the way to the sky island"

Death_Hunt2 = "As you hunt for some food, a bear comes out of nowhere and eats you alive."

Death_Island2 = "You swim towards the island until you see a shadowy figure underwater. Before you can even realise its a shark, it bites your limbs off."

Phrase_Chicken1 = "You eat the tasty chicken until you are full. You walk around until you are on the sandy shore of the island. Far away you see a weird shadowy figure. You realise that the shadowy figure is a broken helicopter. Do you go inside the broken helicopter and loot it or do you go back into the forest?"
Text_Helicopter1 = "Helicopter"

Phrase_Cow1 = "That cow was delecious! As you look around for more animals to hunt, you find trails of somekind of unknowned footprint. You start to follow these trails until you hear a loud noise. Do you head over to the loud noise or do you continue to follow the trails of footprints? "
Text_Noise1 = "Noise"
Text_Trail1 = "Trails"

Phrase_Chicken2 = "You kill the chicken with the bow and now you're stuck with a raw dead chicken that you cant even cook because you have no fire... You walk for a few days until you find a bunch of very tall and pointy mountains that you never have seen before. They were higher than the clouds and very steep. Near these mountains you also find an icy biome. This ice biome had ice instead of ground that you have to step on to slide across. Do you go at the mountains or in the ice biome?"
Text_Mountain1 = "Mountains"
Text_Ice1 = "Ice biome"

Phrase_Boar1 = "You kill the boar with the bow and now you're stuck with a raw dead boar that you cant even cook because you have no fire... You walk for a few days until you find a bunch of very tall and pointy mountains that you never have seen before. They were higher than the clouds and very steep. Near these mountains you also find an icy biome. This ice biome had ice instead of ground that you have to step on to slide across. Do you go at the mountains or in the ice biome?"

Phrase_Treasure1 = "In this treasure room, you find a bunch of gold and pearls! You swim around in the treasure for almost an hour before seeing someone that caught your eye, a huge diamond the size of an apple, so you take it with you. Do you keep searching this dungeon or do you leave? "

Phrase_Weapon1 = "In the weapon room, you find absolutely nothing. Do you keep on searching the dungeon or do you leave?"

Death_Walk1 = "You keep on walking for days and you still cant find anything. All of a sudden, you feel an earthquake underneath you and a huge rock creature comes out of the ground and squashes you like a bug."

Phrase_Ocean1 = "You look at the gorgeous ocean in front of you. Do you go swimming in this ocean or do you sleep for the rest of the day?"

Phrase_Sound1 = "You hear a very loud sound, almost like a growl. Do you run away from this growl or do you stand up to it?"

Phrase_Sneak1 = "You sneak around the village trying not to be seen. You find some food that you can eat. On your way to the food, a woman tackles you to the ground from behind before you can react and fight back. She alarms the other tribe people and they surround you with spears. Do you offer them anything for your survival? **You can only offer a diamond if you have one**  "
Text_Nothing1 = "Nothing"
Text_Diamond1 = "Diamond"

Death_Walk2 = "As you walk away from the village,you hear something coming at you from your left, its a tribeman. Before you can run away, he throws his spear at you and finishes you off. "

Death_Revenge1 = "You run towards them and start to shoot a bunch of arrows which succesfully kills a few. But they are fast enough to sprint towards you and dodge some of the arrows. They completly outnumber you and kill you with their spears."

Phrase_Kill2 = "You killed a bunch of those magma creatures and only took -20HP from scratched and burns. Now that you are tired, do you rest on the floor or do you go back to the plane that crashed here on the island? "
Text_Rest1 = "Rest"

Death_Run5 = "You run away from the magma creatures but they keep on coming. Eventually you become cornered and the amount of magma creature that were first there multiplied by 10 times. They all attack at once and kill you once you started to get exhausted."

Death_Tracks1 = "You follow its tracks until you see a village up ahead. You quickly realise that this village was his home. As soon as you realized it, a bunch of tribe people attack you and kill you in a matter of seconds. "

Death_Opposite1 = "You start to run away in the opposite direction until you see a village up ahead. You quickly realise that this village was his home. As soon as you realized it, a bunch of tribe people attack you and kill you in a matter of seconds. "

Death_Drink1 = "Immediatly after drinking the potion, your throat feels like its on fire and a couple seconds later, you black out and die."

Phrase_Keep1 = "You keep the potion in your hands while you run away from this shady cult until only a few steps away you see another cult member who is looking straight at you. He pulls out a magical wand and start to chant in a foreign language. Do you fight back or do you run away? "

Phrase_Climb3 = "You try to climb back up but halfway there you fall down and hurt your leg which causes -10HP. You realize that its impossible to climb back up. Do you wait or do you make a ladder? **You can only make a ladder if u have an axe** "
Text_Climbing1 = "Climb"
Text_Ladders1 = "Ladder"

Death_Wait1 = "You wait and wait for something to happen for weeks until you die and turn into a skeleton."

Phrase_Sneak2 = "You sneak around the goblin territory for anything that you can steal. You enter a house and all of a sudden you hear a goblin with metal armor entering the same house as you. Do you shoot him with the bow or do you jump out of the window and leave?"

Phrase_Leave1 = "Far away you spot a desert and a small land beside it. Do you go towards that desert or go towards the land? "
Text_Quicksand1 = "Land"

Death_Keep_Going1 = "You keep on walking for a week in the hot sun until you die of dehydration since you coud not find any water."

Death_Back1 = "You turn around to go back and after a day, you realize that you are completly lost in this desert. The sandstorms are making it hard to find the forest that you started off in. You die a week leater from dehydration since you coud not find any water. "

Phrase_Travel1 = "You travel around for a couple of days but you dont find anything interesting except for a huge mountain. Do you climb the mountain or do rest? "

Phrase_Back_Shelter1 = "After a week in your cave, you decide to go out and find a huge mountain. Do you climb the mountain or do you stay in your cave and rest? "

Phrase_Loot1 = "You aquired some treasure that you found, they are kind of heavy though. Do you keep on looting the temple or do you leave?"

Phrase_Leave2 = "You walk around in a forest and find a tree house. This tree house seemed to be built by someone long ago and is abondened. Farther away, you see a swamp biome. Do you climb to the tree house or go to the swamp biome?"
Text_Tree_House1 = "Tree house"
Text_Swamp1 = "Swamp"

Phrase_Button1 = "At first nothing happens, until you feel a bit of water on the ground. And then you start to realize that more water is rising. The whole temple is going to be flooded, do you climb up another ladder that leads to the top of the temple or do you break a wooden door and jump?  "
Text_Break1 = "Break the door"

Death_Hallway1 = "While walking in the hallway, you step on a porcelaine tile and for some reason it made a clicking sound. You get confused and continue walking until the floors open up and you fall into poison spikes. "

Death_Underwater1 = "You start swimming to the sunken city but then you drown since you cant breath underwater. You did not think this through..."

Death_Lava1 = "In this weird lava island, you find nothing but lava until you see some shadows in a cave. They seemed to be these small magma creatures. They outnumber you and since you dont have a strong weapon to defend yourself, they kill you."

Phrase_Lava1 = "In this weird lava island, you find nothing but lava until you see some shadows in a cave. They seemed to be these small magma creatures. They outnumber you but since you have a sword to defend yourself, you kill all of them. You look more into this island full of lava and find a place where it isnt full of lava but insteand of rocks. To your suprise, you found a working plane in the middle of this land. Do you fly this plane to civilization or do you ignore it?"

Death_Eat1 = "After eating thatt weird fruit, you dont feel so good. You look down and see that your skin turned purple. All of a sudden you just explode randomly."

Phrase_Sleep2 = "After a good night sleep, you hear thunder deep into the forest. It seems to be a bunch of random lightning strikes focused on one point. Do you head over to the lightning to check whats going on or do you go towards the opposite direction? "
Text_Lightning1 = "Lightning"

Death_Left1 = "You walk into the left room and find these test tubes with a weird liquid inside. Inside of these test tubes you find dinosaurs inside. And around those seem to be an advanced lab researching on dinosaurs. All of a sudden, russian soldiers come bursting through a door with the alarm on. They shout at you in russian and shoot you down."

Death_Right1 = "You walk into the right room and find these test tubes with a weird liquid inside. Inside of these test tubes you find dead dinosaurs inside. And around those seem to be an advanced lab researching on dinosaurs. All of a sudden, russian soldiers come bursting through a door with the alarm on. They shout at you in russian and shoot you down."

Phrase_Helicopter1 = "In the helicopter you find nothing important except for a full gallon of gasoline. You scout around the helicopter for something that you can use until you hear a loud sound. Do you ignore it or head over to that loud noise?"

Phrase_Noise1 = "You head over to the loud noice and find nothing, maybe it was your imagination... Do you create a new fire or do you rest?"

Death_Trails1 = "You follow the trails for about 20 minutes until you start to see blood surrounding those footprints. You look around some more and a grizzly bear jumps out from the shadows and eats you alive."

Phrase_Mountain1 = "One of the mountains connects to another using a wooden bridge. Do you climb the mountains or do you use the wooden bridge? "
Text_Bridge1 = "Bridge"

Phrase_Ice1 = "Do you climb up a snowy mountain that you found or side across the ice around it?"
Text_Icy1 = "Ice"

Phrase_Leave3 = "Now that you left the dungeon, you look around it and find an ancient temple near. Do you enter the temple or do you build a wooden hut using your axe? **You can only build a hut if you have an axe** "
Text_Build1 = "Build"

Death_Swim3 = "You swim around for a while and have fun. But then you see a huge shadowy figure coming from the bottom of the sea. Before you can even realize its a whale, it becomes too late to swim away and it eats you whole."

Death_Sleep3 = "You sleep on the beach and relaxe for the entire day, until a pack of hungry wolves comes out of nowhere and eats you while you are napping."

Death_Run6 = "The growls were the pack of wolves. Since you are injured, you cant run away as fast anymore from them. They catch up and they eat you alive."

Death_Fight2 = "You decide to stand up to the growls and from the shadows you see the pack of wolves again. You take out your pocket knife and stab a few but its not enough. They outnumber you and eat you alive."

Death_Nothing1 = "You have nothing to offer so they go ahead and execute you on the spot."

Phrase_Diamond1 = "You gave them the diamond that you got from the goblin village and to your suprise, they start chatting amongst themselves. An old bearded tribeman comes out of his hut and explains to you that that diamond is very rare and important to their tribe culture. He asks you where you got it and you bargain that you will tell him where you found the diamond only if he realises you and heals you (+20HP). He accepts and he lets you go and even let you stay in the village for a while as graditude of the diamond. You tell him that you found the diamond in a goblin village and you also tell him the directions to it. They immediatly start to head to the goblin village for a raid for more diamonds. Do you stay in the village for a while or do you join the raid and fight with them? "
Text_Stay_Away1 = "Stay away"

Death_Rest1 = "You sleep on the rocks for a while but you are waken by a bunch more magma creature. There mustve been more hiding in a cave. They all jump on you and kill you while you were on the floor."

Death_Run7 = "You run away for but the more you run away, the more show up. They are suprisingly fast too. Eventually you become cornered and the amount of magma creatures that were first there multiplied by 10 times. They all attack at once and kill you once you started to get exhausted. "

Phrase_Fight3 = "He shoots a magical spell from his wand which only grazed your neck (-10HP). You freak out and throw the potion that you stole at him and it just explodes which caused him to blow up and die. You run away for about 10 minutes, do you rest or do you make a fire?"

Phrase_Attack2 = "You shoot you an arrow at the goblin and luckily hit him in the eye, instantly killing him. You look around more in the house and find a sword and a huge diamond. You end up leaving the village since its too dangerous. While walking around, you find an ancient temple. Do you shelter in a cave or do you enter the temple?"

Death_Leave4 = "You jump out of the window which not only hurt you but made a loud noise. The goblins in the village heard and ambushed you."

Death_Quicksand1 = "While walking in the land, you start to notice that its become harder and harder to move. You try to take a step but then you realizze that your foot is stuck in quicksand. You try to pull it out but your other foot got stuck too. You slowly sink in the quicksand and suffocate."

Death_Mountain2 = "You walk up the mountain until you start to hear a rumbling, and it seems to be coming closer. It becomes louder and louder until you look and realize that a boulder is rolling towards you. With no time to react, it squashes you."

Phrase_Rest2_Sunny = "You wake up to a nice and sunny day. Far away you notice a lot of smoke and you also notice a bunch of dead animal bodies on the ground in an other directions. Do you go to the smoke or do you go to the dead animal bodies"
Phrase_Rest2_Rain = "You wake up to a rainy day. The cold rain made you sick for a couple of days (-10HP), but you are fine now. Far away you notice a lot of smoke and you also notice a bunch of dead animal bodies on the ground in an other directions. Do you go to the smoke or do you go to the dead animal bodies"
Phrase_Rest2_Tornado = "You are woken up in the middle of the night by a heavy wind which caused a small tree to fall on you and deal -50HP. Far away you notice a lot of smoke and you also notice a bunch of dead animal bodies on the ground in an other directions. Do you go to the smoke or do you go to the dead animal bodies"
Phrase_Rest2_Heatwave = "You wake up to a heatwave which causes you to have a minor heatstroke (-20HP). Far away you notice a lot of smoke and you also notice a bunch of dead animal bodies on the ground in an other directions. Do you go to the smoke or do you go to the dead animal bodies"
Text_Smoke1 = "Smoke"
Text_Animals1 = "Dead animals"

Death_Loot2 = "As you decide to loot more treasure, you find another treasure room. You enter it but as soon as you step into the new treasure room, the stone door closes on you and keeps you there until you die of starvation. "

Phrase_Tree_House1 = "As you climb this tree house, you find nothing important inside. Though you decide to live in it for a couple weeks. You finally decide to leave the tree house and to adventure around the island. While adventuring you find a desert and a horse, Do you travel around in the desert or do you tame the horse?"

Phrase_Swamp1 = "You arrive at the swamp and find a random wooden hut. Do you travel around or enter the hut? "
Text_Witch1 = "Hut"

Phrase_Climb4 = "You are now at the last level of the temple. You find yourself outside on the roof with walls surrounding you that are about 2 feet tall. The water is still rising underneath you. Do you jump off the temple or stay on the roof?"
Text_Jump1 = "Jump"
Text_Stay1 = "Stay"

Phrase_Break1 = "You succesfully break the door and jump out and land safely. You start to adventure around and find this weird and huge rock. You also hear this strange sound. Do you climb the weird rock or do you go towards the noise?"
Text_Rock1 = "Weird rock"
Text_Hear1 = "Noise"

Phrase_Plane2 = "You succesfully take off, but after a bit, you start noticing a bit of turbulence. Do you continue to fly and control the plane or do you jump with a parachute? "
Text_Control1 = "Control"
Text_Parachute1 = "Parachute"

Phrase_Ignore4 = "While walking around, you find an abandoned mineshaft. Near that mineshaft you found an exotic flower field. Do you go to the mineshaft or the flower field?"
Text_Mine1 = "Mineshaft"
Text_Flower1 = "Flower field"

Death_Lightning1 = "As you get closer to the place full of lightning, you see someone standing around surrunded by electricty. He senses you and turns around and looks at you. All of a sudden, a lightning bolt strikes and kills you."

Phrase_Opposite2 = "You find a small sea and beside that you find a huge cave. Do swim in the sea or do you enter the huge cave?"
Text_Sea1 = "Small sea"
Text_Dragon1 = "Huge cave"

Phrase_Ignore5 = "While walking on top of a cliff, you spot an object far away underneath you. Do you jump from rock to rock downwards so you can reach the ground faster or do you take the long route downwards by walking? "
Text_Item1 = "Parkour"
Text_Snake1 = "Long way"

Phrase_Noise2 = "You show up to the place where the noise originated from and you find absoltely nothing. Do you make a fire or do you rest for the night?"

Phrase_Fire3 = "As finish making your fire, you start to hear the same noise that you originatly came here for. But this time its getting closer and closer so you start to back away. You look up and see a small giant about four time you size. Do you throw the tank of gasoline at him or do you run away?"
Text_Throw1 = "Throw"

Phrase_Rest3 = "As finish taking a nap, you start to hear the same noise that you originatly came here for. But this time its getting closer and closer so you start to back away. You look up and see a small giant about four time you size. Do you throw fight him or do you run away?"

Death_Climb5 = "You try to climb one of the mountains but they are so steep that you lose your grip and fall to your death"

Death_Bridge1 = "You take the bridge but halfway there you start to hear some creeks. You then realize that the bridge is on the verge of collapse and before you know it, it breaks and you fall to your death. "

Death_Mountain3 = "You climb up the mountain until you hear a sound. It becomes louder an louder and you also start to feel a vibration in the ground. You look up and see an avalanche coming towards you. It crushes you with no hope of survival."

Death_Icy1 = "You slide on the ice for a while until you hear a crack in the ice. You look down and realize that the ice under you is breaking. You fall into the ice cold water and become unable to get back up to the surface. You die within an hour from hypothermia. "

Phrase_Temple2 = "You walk in to a temple and at first you find nothing usefull, until you see an orb. The orbs starts randomly glowing and an angel godess apperes out of nowhere. She tells you that you have two choices, either she'll give you a flare gun or she'll give you iron armor. Which do you chose? "
Text_Flare1 = "Flare gun"
Text_Armor1 = "Iron armor"

Phrase_Build1 = "After a month of building your hut, you finish. Near your hut, you find a very dark cave that you cant even see inside. Do you make a fire in your hut to keep yourself warm while you sleep or do you enter the dark cave?  "

Death_Stay_Away1 = "They let you stay in the village for a week in gratitude of the diamond. Suddenly, a day after the men went to raid, you start to hear goblins rushing towards you. The raid must've failed and now the goblins want revenge. They outnumber you and the people left in the tribe and completly anhilates all of you. "

Phrase_Fight4 = "As you rush into the fight, you kill a goblin using your bow. You shoot another but he dodges and slices your arm which causes -30HP. You enter on e of the goblin huts and find a golden key on the floor so you take it. You look out a window and find a mountain near you. Do you stay and continue to fight,climb the mountain or go back to the tribe where they can heal your arm out of respect for helping in the raid?"
Text_Tribe1 = "Tribe village"

Death_Rest4 = "As you take a nap, you are awoken by sounds of footsteps. You then realize that the cult were chasing after you. They must've heard the explosion and followed your footsteps. They all take out their wand and kill you."

Death_Fire4 = "As you make a fire, you hear sounds of footsteps. You then realize that the cult were chasing after you. They must've heard the explosion and followed your footsteps. They all take out their wand and kill you."

Death_Smoke1 = "You head towards the smoke and find that there is a forest fire. The smoke got into your eye and you cant see very well. You try to exit the forest but you become surrounded by the fire until you inhaled too much smoke and died. "

Death_Animals1 = "As you look at the trail of dead animals, you hear a growl and behind you, a tiger appears. He jumps on you and adds another corpse to his collection."

Death_Witch1 = "You enter the hut and find a couldron with a weird bubling liquid inside. As you come closer to check on the liquid, a witch creeps on behind you and curses you with a spell that turned you into a frog. You live out the rest of your life eating bugs and jumping around. "

Death_Jump1 = "You jump out of the roof of the temple but break you neck when you hit the floor which caused you to die. "

Phrase_Stay1 = "You stay on the roof of the temple while the water is filling up. Eventually, since you're on the roof, the water overflows from the 2 feet tall walls. You can now think of a way to safely go down from the temple. While on the ground, you start to adventure around and find this weird and huge rock. You also hear this strange sound. Do you climb the weird rock or do you go towards the noise?" 

Death_Rock1 = "You sit on this weird rock but for some reason it is hollow and you fall isnide of it. You are now covered with this slimey goo and beside you, there seems to be this creature. You realize that this is nor a rock but a dragon egg. You escape from the egg but you are greeted with a very angry dragon that stomps on you after you killed its kid."

Death_Hear1 = "You enter a cave where you heard the noise in a slow manner and as you come closer, a huge eye appears from the shadow. You turn around and run but as you look back, you realize that it was a dragon. It flies at you and burns you alive with its fire breath."

Death_Control1 = "You try to control the plane but the plane start to breakdown. The engine fails and before you can jump out of the plane, it crashes in the sea which kills you. "

Phrase_Parachute1 = "You jump out of the plane and land safely onto some trees and bushes. You land near what seems to be a mineshaft and an exotic flower field. Do you go in the mineshaft or do you go into the flower field?"

Death_Mine1 = "You enter the mine and look around. There are no lights whatsoever but you see a faint light at the end of a tunel. As you walk over to that light, you see a warning sign that says turn back but you decide to keep on going. You take a step forward but you dont feel the ground. Since there are no lights, you couldnt see that there was a very deep hole in the ground and you fall to your death."

Death_Flower1 = "You walk in the thick flower field, rubbing your body against the strange looking plants. After a minute, you start to feel a itch on your leg. After 5 minutes you find a rash on your arm. After 10 minutes your eyes becomes red. After 15 minutes you realixe that the flowers were poisonous and after 20 minutes, your skin turned purple. Finnaly, after 30 minutes, you die from highly poisonous flowers that you rubbed against."

Death_Sea1 = "You swim in the sea for a while and you have fun until a bunch of 10 feet tall piranhas jump out of the water and eat you up."

Death_Dragon1 = "You enter the cave in a slow manner and as you come closer, a huge eye appears from the shadow. You turn around and run but as you look back, you realize that it was a dragon. It flies at you and burns you alive with its fire breath."

Phrase_Item1 = "The item that you found was a map of the island. What caught your eye about the map is that there are two spot on the map that are circled with a sharpie. You knwo where you are on the map currently. Do you go twoards the first circle (the one on the left of the island) or do you go to the second circle (the one on the right of the circle)?"
Text_First1 = "First"
Text_Second1 = "Second"

Death_Snake1 = "As you take the long way around, you walk through this bush and you feel like something pinched you. You look down and find that a venomous snake bit you on your leg. You kick it off but unfortunetly die after a day from the venom."

Phrase_Throw1 = "You thro the gasolone at him but it lands in the fire, and explodes. The explosion was so strong that it was able to knock him off of his feet. You keep on running towards a beach. Do you hid from the giant or do you swim away from him?"
Text_Hide1 = "Swim"

Death_Run8 = "You try to run away from the giant but he is too fast. He stomps on you with no hesitation."

Death_Fight5 = "No chance"

Phrase_Flare1 = "You leave the temple and decide that you want to make a stone axe. After you finish making it, you either want to build a wooden boat to leave the island or you want to build a wooden hut. Which do you built?"
Phrase_Flare1_Axe = "You leave the temple and decide that you want to make a stone axe. After you finish making it, you either want to build a wooden boat to leave the island or you want to build a wooden hut. Which do you built?"
Phrase_Flare1_No_Axe = "You leave the temple, you decide that you either want to build a wooden boat to leave the island or you want to build a wooden hut. Which do you build?"

Text_Boat1 = "Boat"

Phrase_Armor1 = "After a week of traveling around the island, you hear a plane. You look up and see a rescue plane. You need to get its atention quick and you have no time to take off all of your iron armor. Do you run towards the trajectory of the plane or do you climb up a mountain that is not near its trajectory but high enough for it to see you?"

Death_Fire6 = "After you make the fire in your house, you go to sleep but you are awoken in the middel of the night when the fire spread and burns you rhouse down while you are trapped inside. The smoke sufficates you and you die. "

Death_Cave3 = "You walk into the dark cave and accidently bump your head onto something. You're not sure what you bumped your head into until you hear multiple buzzing sounds. You bumped your head onto a huge wasp nest. These are not any normal wasps but they are instead a 2 inch hge killer wasps. You run away but tehy are faster and after 30 stigs of these killer wasps, you die."

Death_Stay2 = "You keep on killing the goblins until one of them sneaks up behind you and stabs you in the back. You bleed out on the ground. "

Phrase_Climb6 = "You succesfully climb the mountain and to your suprise, you find a metal door that leads inside of the mountain. You also find a goblin far away with what seems to be an assault rifle. You are not sure how a goblin could aquire that item but you realize that you can sneak up towards him and shoot him with the bow from far away and steal the gun. Do you go towards the metal door or do you shoot the goblin?"
Text_Decrypt1 = "Metal door"
Text_Shoot1 = "Shoot"

Death_Tribe1 = "As you head back to the tribe village, you turn your back against the goblin village. And a sneaky goblins follows you. Halfway to the tribe, he gets close enough to throw his dagger at you and piecres your skull."

Phrase_First1 = "You chose the spot circled by the first circle. After you arrive, you find this weird military base. In this base you find a manhole with a ladder going down underground and you also find a big tent. Do you climb down the ladder or do you go inside the tent?"
Text_Tent1 = "Tent"

Phrase_Second1 = "You chose the spot circled by the second circle. After you arrive, you find this weird military base. In this base you find a manhole with a ladder going down underground and you also find a big tent. Do you climb down the ladder or do you go inside the tent?"

Death_Hide1 = "You try to hid in a bush. In the bush, you see the giant looking for you. After a while he starts to get angry, angry enough to start stomping and kicking everything he sees. Eventually he goes in a rage and kicks the bush that you are hidden in and flings you to the "

Death_Swim4 = "You try to swim away but the giant spots you right away and jumps in the water. He grabs and drowns you. "

Death_Boat1 = "Halfway there to finishing the boat, you hear a pack of wolves charging towards you. You try to defend yourself but they are too many. If only you had armor... "

Death_Hut2 = "Halfway there to finishing the hut, you hear a pack of wolves charging towards you. You try to defend yourself but they are too many. If only you had armor... "

Death_Run9 = "As you run towards the trajectory of the plane, it still does not see you. You keep flaning your arms trying to get its attention. While looking at the plane, you do not notice that there is a cliff infront of you. You fall down the cliff to your death. If only you had a flare gun... "

Death_Mountain4 = "As you run towards the top of the mountain, the plane still does not see you. You keep flaning your arms trying to get its attention. While looking at the plane, you do not notice that there is a cliff infront of you. You fall down the cliff to your death. If only you had a flare gun... "

Phrase_Decrypt2 = "As you come close to the door, you hear a beep and all of a sudden a timer of 3 minutes pops up. You notice a place to digitally write a password and above that you find the words: 'Monster','Africa','Ruler','Cup'. Figure out the password in 3 minutes or else you have no choice other than to shoot the goblin since hes coming towards your way."

Death_Shoot1 = "You take a shot at him and fire. You hit the goblin, but only in the shoulder. He turns around and fires a barrage of bullets at you. Unfortunately, one of the bullets hits your head."

Death_Ladder2 = "You climb down the ladder into a sewer. You look around and hear a weird noise. You come closer to this noise and see a huge muntant rat the size of a big dog. Its eyes are red and it is foaming in the mouth. he jumps at you and bites you. You take out your pocket knife and stab it in the head, which kills it. But its too late since it poisoned you with its diseases. "

Phrase_Tent1 = "You enter the tent but you do nut find any items intersting. But you find this weird pin that you could pull in a box of objects. Do you go down the ladder that you found earlier or do you pull the pin?"
Text_Pull1 = "Pull"

Phrase_Correct1 = "You deciphered the code! You enter through the door and you find yourslef in a secret military base. You walk around and you find nothing but doors and hallway. One door peaks your interest since it has the same key hole shape as your key that you found. On top of finding this door, you also find a wall of assault rifles, pistols and body armor on the wall on the other side of the hallway. Do you go through the door or take the weapons and body armor?"
Text_WIN = "Door"
Text_Guns1 = "Guns and armor"

Death_Pull1 = "You pull the pin but nothing happens. You look closely in the box of objects and find that you pulled the pin out of the grenade... It explodes immediatly after."

Death_Guns1 = "As you come close to the weapons, you hear an alarm going off. All of a sudden, a bunch of millitary men come out of the rooms and shoot you with no hesitatyion."

Phrase_WIN = "As you enter the door, you find a working helicopter and you decide to use it to leave the island. You fly away over the sea until you find a country which you land on. It happens that this country is england and that the citizen speak english. You go to the police and tell them everything. YOU ARE RESCUED!!!! "