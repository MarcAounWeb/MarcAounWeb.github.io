from tkinter import *

root = Tk()
def die():
    print("test")

def update(new_time):
    if new_time == 0:
        die()
    newer_time = 0
    newer_time += new_time-1
    My_Label.config(text= newer_time)
    My_Label.after(1000, lambda: update(newer_time))


    
My_Label = Label(root, text = "time")
My_Label.pack()
My_Label.after(1000, lambda: update(10))


mainloop()